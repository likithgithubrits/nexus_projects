import random

# Greeting function
def greeting():
    return "Hello! I'm your chatbot. How can I assist you today?"

# Farewell message
def farewell():
    return "It was great chatting with you. Goodbye!"

# Function to handle various types of questions
def handle_question(question):
    # Dictionary of predefined responses based on different question types
    responses = {
        "What can you do?": [
            "I can provide information, crack jokes, or simply have a conversation with you!",
            "I'm here to help with information, humor, or just to chat!",
            "My capabilities include answering questions, telling jokes, and engaging in conversation."
        ],
        "How are you?": [
            "I'm doing well, thank you!",
            "Feeling great today!",
            "I'm fantastic, ready to assist you!"
        ],
        "Tell me a joke.": [
            "Why don’t scientists trust atoms? Because they make up everything!",
            "What do you call a fake noodle? An impasta!",
            "Why did the bicycle fall over? Because it was two-tired!"
        ],
        "Can you help me?": [
            "Absolutely! What do you need assistance with?",
            "Sure thing! Tell me what you need help with.",
            "Of course, I'm here to help. What can I do for you?"
        ],
        "Who created you?": [
            "I was brought to life by a team of brilliant developers.",
            "My creators are a talented group of individuals.",
            "I came into existence thanks to some amazing developers."
        ]
    }

    # Check if the question exists in the responses dictionary
    if question in responses:
        return random.choice(responses[question])
    else:
        return "I'm sorry, I didn't understand that. Please ask something else."

# Function to start the conversation
def start_conversation():
    print(greeting())  # Greet the user

    # Conversation flow
    for _ in range(3):  # Ask three questions
        user_input = input("Ask me something: ")  # Get user input
        response = handle_question(user_input)  # Handle user input

        print(response)  # Print the response

    print(farewell())  # Say goodbye when the conversation ends

# Start the conversation
start_conversation()
